import "../styled/Footer.css";

function Footer() {
  return (
    <footer>
      <p>© 2024 자쿠과. All rights reserved.</p>
      <p>@자쿠과</p>
      <p>연락처: 000-0000-0000</p>
    </footer>
  );
}

export default Footer;
